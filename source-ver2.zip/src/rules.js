export const STAGE_COUNT=5, BOSS_SECONDS=30, MAX_TROOPS=243, LEAF_COST=7, BLAST_FRACTION=.6;
export const WEAPONS=[{name:'일반',damage:1,color:0xf5cf49},{name:'파란',damage:3,color:0x559cff},{name:'무지개',damage:7,color:0xe99bff}];
export const EVOLUTIONS=[{name:'일반',weight:1,bonus:1},{name:'황금',weight:3,bonus:1.3},{name:'무지개',weight:9,bonus:1.6}];
export const ENEMIES=[{name:'꼬마 사과',hp:38,size:1.35},{name:'튼튼 사과',hp:150,size:2},{name:'사과 왕',hp:2600,size:3.6}];
export const THEMES=[
  {name:'초록빛 과수원',sky:'#b8ce91',ground:'#a8c477',road:'#d9c698',tint:'#ffffff',trees:24,fences:30,ambient:2.7,sun:3,light:'#fff0c9'},
  {name:'이슬 맺힌 숲길',sky:'#819d96',ground:'#6a957d',road:'#9ea68c',tint:'#c4e7d3',trees:32,fences:36,ambient:2.1,sun:2.3,light:'#dfe9ef'},
  {name:'푸른 그늘 정원',sky:'#3f5874',ground:'#365b5f',road:'#64727c',tint:'#9ab6d2',trees:40,fences:42,ambient:1.5,sun:1.7,light:'#aecaff'},
  {name:'깊어지는 청록숲',sky:'#182b49',ground:'#203b45',road:'#455667',tint:'#7e99bd',trees:48,fences:48,ambient:1,sun:1.25,light:'#90b5ff'},
  {name:'사과 왕의 푸른 성역',sky:'#080f25',ground:'#13232f',road:'#304255',tint:'#6680ac',trees:56,fences:54,ambient:.7,sun:.95,light:'#81a7ff'},
];
export function applyGate(count,op,value){
  if(!Number.isInteger(value)||value<1)throw new Error('Invalid gate');
  const n=op==='+'?count+value:op==='×'?count*value:op==='−'?count-value:op==='÷'?Math.floor(count/value):NaN;
  if(!Number.isFinite(n))throw new Error('Invalid operator');
  return Math.max(0,Math.min(MAX_TROOPS,n));
}
// Preserve original-monkey manpower: 3 normals = 1 gold, 3 golds = 1 rainbow.
// Remainders stay as lower-rank monkeys, without loss or free extra soldiers.
export function evolutionFor(count,previous=0){let rank=previous;while(rank<2&&formation(count,rank).length>30)rank++;return rank;}
export function formation(count,rank){const units=[];for(let r=rank;r>=0;r--){const n=Math.floor(count/EVOLUTIONS[r].weight);for(let i=0;i<n;i++)units.push(r);count%=EVOLUTIONS[r].weight;}return units;}
export function troopPower(count,rank,weapon){return Math.round(formation(count,rank).reduce((sum,r)=>sum+EVOLUTIONS[r].weight*EVOLUTIONS[r].bonus,0)*WEAPONS[weapon].damage*10)/10;}
export function rosterPower(units,weapon){return Math.round(units.reduce((sum,r)=>sum+EVOLUTIONS[r].weight*EVOLUTIONS[r].bonus,0)*WEAPONS[weapon].damage*10)/10;}
export function mergeRoster(input){
  let weight=0;
  let units=[...input].sort((a,b)=>b-a).filter(r=>{if(weight+EVOLUTIONS[r].weight>MAX_TROOPS)return false;weight+=EVOLUTIONS[r].weight;return true;});
  while(units.length>30){
    const rank=[0,1].find(r=>units.filter(v=>v===r).length>=3);if(rank===undefined)break;
    const n=units.filter(r=>r===rank).length,merged=Math.floor(n/3);
    units=units.filter(r=>r!==rank).concat(Array(n%3).fill(rank),Array(merged).fill(rank+1));
  }
  return units.sort((a,b)=>b-a);
}
export function gateRoster(units,op,value){
  const desired=applyGate(units.length,op,value);
  if(op==='+')return mergeRoster(units.concat(Array(Math.max(0,desired-units.length)).fill(0)));
  if(op==='×')return mergeRoster(Array.from({length:value},()=>units).flat());
  return units.slice(0,desired); // Preserve the strongest survivors; never split an evolved monkey.
}
export function collisionSurvivors(count,hp,maxHp){const fraction=Math.min(1,Math.max(0,hp/maxHp));return Math.max(0,Math.floor(count*(1-fraction)+1e-9));}
export function collisionOverlaps(appleX,appleSize,troopX,unitCount){return Math.abs(appleX-troopX)<=appleSize*.42+Math.min(6,unitCount)*.27;}
export function touchedUnits(appleX,appleZ,appleSize,troopX,unitCount){
  const hits=[],radius=appleSize*.42+.2;
  for(let i=0;i<unitCount;i++){
    const row=Math.floor(i/6),cols=Math.min(6,unitCount-row*6);
    const x=troopX+(i%6-(cols-1)/2)*.52,z=1.2+row*.58;
    if(Math.hypot(appleX-x,appleZ-z)<=radius)hits.push(i);
  }
  return hits;
}
export function frontRowOffsets(count){const n=Math.min(6,count);return Array.from({length:n},(_,i)=>(i-(n-1)/2)*.52);}
export function gateContains(gate,x){return Math.abs(x-gate.x)<=gate.width/2;}
// Swept relative motion prevents a fast banana or approaching apple from skipping a hit.
export function projectileHitTime(shot,oldZ,newZ,apple){
  const radius=ENEMIES[apple.level].size*.42+.13,dx=shot.x-apple.x;
  if(Math.abs(dx)>radius)return null;
  const half=Math.sqrt(radius*radius-dx*dx),from=oldZ-(apple.previousZ??apple.worldZ),to=newZ-apple.worldZ;
  if(Math.abs(from)<=half)return 0;
  if(from>half&&to<=half)return (from-half)/(from-to);
  if(from<-half&&to>=-half)return (-half-from)/(to-from);
  return null;
}
export function spendLeaves(leaves){return leaves>=LEAF_COST?{used:true,leaves:leaves-LEAF_COST}:{used:false,leaves};}
export function blastHp(hp,maxHp){return Math.max(0,hp-maxHp*BLAST_FRACTION);}
export function readLeaves(raw){const n=Number(raw);return Number.isSafeInteger(n)&&n>=0?n:0;}
export function seededRandom(seed){return ()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296;};}
export function makeStage(stage,random=Math.random){
  if(stage<1||stage>STAGE_COUNT)throw new Error('Invalid stage');
  const events=[],scale=1+(stage-1)*.38,blocks=10+stage*2;
  const pickX=()=>Math.round((random()*6.6-3.3)*100)/100;
  events.push({z:-12,x:pickX(),type:'gate',width:2.6,op:'+',value:12});
  for(let i=0;i<blocks;i++){
    const at=32+i*24,pair=i%4===2||random()<.24;
    for(let j=0;j<(pair?2:1);j++){
      const level=random()<.57?0:1,x=pair?(j===0?-1:1)*(1.5+random()*1.4):pickX();
      events.push({z:-at,x,type:'enemy',level,hp:Math.round(ENEMIES[level].hp*scale),approach:0,speed:1+random()*.7});
    }
    if(i===2||i===6)events.push({z:-at-10,x:0,type:'item',tier:i===2?1:2});
    if(i%2===1){
      const n=random()<.55?2:1;
      for(let j=0;j<n;j++){
        const choice=random(),op=choice<.4?'+':choice<.65?'×':choice<.85?'−':'÷';
        events.push({z:-at-8-j*8-random()*3,x:pickX(),type:'gate',width:2.2+random()*.6,op,value:op==='+'?10+stage*2:op==='−'?5+stage:2});
      }
    }
    events.push({z:-at-5-random()*4,x:pickX(),type:'leaf'});
    if(random()<.3)events.push({z:-at-11,x:pickX(),type:'leaf'});
  }
  events.push({z:-(32+blocks*24+18),x:0,type:'enemy',level:2,hp:Math.round(ENEMIES[2].hp*scale),approach:0,speed:0,crowned:stage===5});
  return events.sort((a,b)=>b.z-a.z);
}
