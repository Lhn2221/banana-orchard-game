import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Game} from './game.js';
import {seededRandom,collisionSurvivors,touchedUnits} from './rules.js';
const tick=(g,seconds)=>{for(let i=0;i<Math.ceil(seconds/.05);i++)g.update(.05);};

test('contact selects individual positions, excluding distant columns and back rows',()=>{
  assert.deepEqual(touchedUnits(0,1.49,1.35,0,20),[2,3,8,9]);
  assert.deepEqual(touchedUnits(3.2,1.49,1.35,0,20),[]);
});
test('regular enemies advance throughout combat instead of stopping the road',()=>{
  const g=new Game({random:seededRandom(1)});g.start();const e=g.events.find(e=>e.type==='enemy');
  g.distance=-e.z-12;const before=g.distance;tick(g,.1);
  assert.ok(g.distance>before);assert.ok(e.approach>0);
});
test('collision applies once, healthy apples remove only touched units, and lateral misses do no damage',()=>{
  for(const hp of [100,25]){
    const g=new Game();g.start();g.changeTroop(20);g.shotClock=100;
    const e={id:999,type:'enemy',level:0,z:1.2,x:0,hp,maxHp:100,approach:0,speed:1,worldZ:1.2};g.events=[e];
    tick(g,.05);assert.equal(g.count,20-4+collisionSurvivors(4,hp,100));assert.equal(e.done,true);
    tick(g,.2);assert.equal(g.count,20-4+collisionSurvivors(4,hp,100));
  }
  const g=new Game();g.start();g.shotClock=100;g.x=g.targetX=-3.2;
  g.events=[{id:999,type:'enemy',level:0,z:1.2,x:3.2,hp:100,maxHp:100,approach:0,speed:1}];tick(g,1);assert.equal(g.count,8);
});
test('boss remains stationary, pause freezes deadline, expiry fails',()=>{
  const g=new Game();g.start();g.events=[g.boss];g.distance=g.endDistance;g.shotClock=100;
  tick(g,.1);const z=g.boss.worldZ,time=g.bossTime;g.pause();tick(g,2);assert.equal(g.bossTime,time);
  g.pause();tick(g,1);assert.equal(g.boss.worldZ,z);assert.equal(g.distance,g.endDistance);
  tick(g,30);assert.equal(g.status,'lost');
});
test('collision removes the same proportion of evolved units without splitting survivors',()=>{
  const g=new Game();g.start();g.changeTroop(100);g.shotClock=100;const before=g.units.length;
  g.events=[{id:999,type:'enemy',level:0,z:1.2,x:0,hp:50,maxHp:100,approach:0,speed:1}];
  tick(g,.05);assert.equal(g.units.length,before-2);assert.equal(g.units.filter(r=>r===0).length,1);
});
test('leaf charge survives stage transition and retry; blast damages every active apple once',()=>{
  const saved=[],g=new Game({leaves:9,saveLeaves:n=>saved.push(n)});g.start();
  g.events=[{id:100,type:'enemy',level:0,z:-10,worldZ:-10,x:-2,hp:100,maxHp:100},{id:101,type:'enemy',level:1,z:-20,worldZ:-20,x:2,hp:200,maxHp:200}];
  assert.equal(g.blast(),true);assert.deepEqual(g.events.map(e=>e.hp),[40,80]);assert.equal(g.leaves,2);assert.deepEqual(saved,[2]);assert.equal(g.blast(),false);
  g.finish(true);g.start();assert.equal(g.stage,2);assert.equal(g.leaves,2);
  g.finish(false);g.start();assert.equal(g.stage,2);assert.equal(g.leaves,2);
});
test('five stages progress to crowned final boss and restart at one without consuming saved skill',()=>{
  const g=new Game({leaves:7});g.start();
  for(let stage=1;stage<=5;stage++){assert.equal(g.stage,stage);assert.equal(g.boss.crowned,stage===5);g.damage(g.boss,g.boss.hp);assert.equal(g.status,'won');g.start();}
  assert.equal(g.stage,1);assert.equal(g.leaves,7);
});
test('six straight shots launch without a target, retain x and conserve volley damage',()=>{
  const g=new Game();g.start();g.changeTroop(20);g.events=[];tick(g,.05);
  assert.equal(g.projectiles.length,6);assert.ok(Math.abs(g.projectiles.reduce((n,p)=>n+p.damage,0)-g.power)<1e-8);
  const lanes=g.projectiles.map(p=>p.x);g.targetX=3;tick(g,.1);
  assert.deepEqual(g.projectiles.map(p=>p.x),lanes);assert.ok(g.projectiles.every(p=>p.z<1));
  g.pause();const positions=g.projectiles.map(p=>p.z);tick(g,1);assert.deepEqual(g.projectiles.map(p=>p.z),positions);
});
test('bananas only damage intersected apples after travel, with no homing or piercing',()=>{
  const g=new Game();g.start();g.events=[];g.shotClock=100;
  const apple=(id,x,z)=>({id,type:'enemy',level:0,x,z,worldZ:z,previousZ:z,hp:100,maxHp:100,approach:0,speed:0});
  const near=apple(0,0,-3),far=apple(1,0,-7),outside=apple(2,3,-3);g.events=[far,outside,near];
  g.projectiles=[{id:1,x:0,z:1,damage:9,weapon:0,dead:false}];
  tick(g,.05);assert.equal(near.hp,100);tick(g,.15);
  assert.equal(near.hp,91);assert.equal(far.hp,100);assert.equal(outside.hp,100);assert.equal(g.projectiles.length,0);
});
test('narrow gates only affect the troop when its center passes inside, once',()=>{
  for(const x of [0,3]){
    const g=new Game();g.start();g.shotClock=100;g.events=[{id:0,type:'gate',x,z:1.2,worldZ:1.2,width:1.8,op:'+',value:5}];
    tick(g,.05);assert.equal(g.units.length,x===0?13:8);tick(g,.5);assert.equal(g.units.length,x===0?13:8);
  }
});


