import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Shop} from './shop.js';
import {Game} from './game.js';
test('rewards, affordable purchases, ownership and equipped skins persist',()=>{
  let saved;const shop=new Shop(null,s=>saved=s);
  assert.equal(shop.buy('rabbit'),false);
  [0,1,2].forEach(level=>shop.reward(level));assert.equal(shop.stones,120);
  assert.equal(shop.buy('rabbit'),true);assert.equal(shop.stones,20);assert.equal(shop.buy('rabbit'),false);
  const restored=new Shop(saved);assert.equal(restored.equipped.troop,'rabbit');assert.equal(restored.stones,20);
  assert.equal(restored.equip('weapon','coconut'),false);restored.equip('troop',null);assert.equal(restored.equipped.troop,null);assert.equal(restored.equip('troop','rabbit'),true);
});
test('only destroyed apples emit one reward event; escaping apples do not',()=>{
  const g=new Game();g.start();g.drain();const e=g.events.find(e=>e.type==='enemy');
  g.damage(e,1);assert.equal(g.drain().filter(s=>s.type==='kill').length,0);
  g.damage(e,e.maxHp);g.damage(e,e.maxHp);assert.equal(g.drain().filter(s=>s.type==='kill').length,1);
  const other=g.events.find(e=>e.type==='enemy'&&!e.done);g.remove(other);assert.equal(g.drain().filter(s=>s.type==='kill').length,0);
});
test('invalid saves cannot equip unowned skins',()=>{const s=new Shop('{"stones":-10,"equipped":{"troop":"rabbit"}}');assert.equal(s.stones,0);assert.equal(s.equipped.troop,null);assert.equal(new Shop('bad').stones,0);});
