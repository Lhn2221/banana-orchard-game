// 수업에서는 이 파일의 숫자를 하나씩 바꾸고 같은 배치로 비교해보세요.
// 스킨은 외형만 바꾸며 전투 수치에 영향을 주지 않습니다.
export const INITIAL_TROOPS = 8;          // 스테이지 시작 병력
export const RUN_SPEED = 4.8;             // 초당 전진 거리
export const SHOT_INTERVAL = 0.65;        // 발사 간격(초): 작을수록 자주 발사
export const PROJECTILE_SPEED = 28;       // 탄환 속도
export const STONE_REWARDS = [20, 30, 70]; // 작은 사과 / 중간 사과 / 보스
export const SKIN_PRICE = 100;            // 모든 꾸미기 스킨 가격
