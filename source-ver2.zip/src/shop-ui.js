import {CATALOG,REWARDS} from './shop.js';
export function installShop(shop,{ready,onOpen,onClose,onEquip,previews}){
  const button=document.createElement('button');button.id='shop-toggle';button.textContent='상점 S · 돌멩이 0';document.querySelector('.header-right').prepend(button);
  const dialog=document.createElement('dialog');dialog.id='shop-dialog';dialog.setAttribute('aria-labelledby','shop-title');
  dialog.innerHTML=`<div class="shop-heading"><div><span class="eyebrow">THE LITTLE FOREST SHOP</span><h2 id="shop-title">원정대의 작은 상점</h2></div><button id="shop-close" aria-label="상점 닫기">✕</button></div><p class="shop-wallet">보유 돌멩이 <strong id="shop-balance"></strong></p><div class="shop-tabs" role="tablist" aria-label="스킨 종류">${CATALOG.map((i,n)=>`<button role="tab" id="tab-${i.category}" aria-controls="shop-panel" aria-selected="${n===0}" data-category="${i.category}">${i.tab}</button>`).join('')}</div><div id="shop-panel" role="tabpanel"></div><p class="shop-note">외형만 변경됩니다 · 공격력과 충돌 범위는 동일해요<br>작은 사과 ${REWARDS[0]} · 중간 사과 ${REWARDS[1]} · 보스 ${REWARDS[2]} 돌멩이</p><p id="shop-message" role="status"></p>`;
  document.body.append(dialog);let category='background';
  function refresh(){
    button.textContent=`상점 S · 돌멩이 ${shop.stones}`;document.getElementById('shop-balance').textContent=`${shop.stones}개`;
    const item=CATALOG.find(i=>i.category===category),owned=shop.owned.includes(item.id),equipped=shop.equipped[category]===item.id;
    const panel=document.getElementById('shop-panel');panel.setAttribute('aria-labelledby',`tab-${category}`);
    panel.innerHTML=`<article class="skin-card"><div class="skin-preview"><img src="${previews[item.id]||''}" alt="${item.name} 3D 미리보기"></div><div class="skin-details"><span class="skin-type">${item.tab} 스킨 · ${owned?'보유 중':`${item.price} 돌멩이`}</span><h3>${item.name}</h3><p>${item.description}</p><button id="skin-action" ${equipped||!owned&&shop.stones<item.price?'disabled':''}>${equipped?'장착 중':owned?'장착하기':shop.stones<item.price?`${item.price-shop.stones} 돌멩이 부족`:`${item.price} 돌멩이로 구매 · 장착`}</button><button id="skin-default" ${!shop.equipped[category]?'disabled':''}>${!shop.equipped[category]?'기본 외형 장착 중':'기본 외형으로 돌아가기'}</button></div></article>`;
    document.getElementById('skin-action').onclick=()=>{const ok=owned?shop.equip(category,item.id):shop.buy(item.id);if(ok){onEquip();refresh();document.getElementById('shop-message').textContent=`${item.name} 장착 완료!`;}};
    document.getElementById('skin-default').onclick=()=>{shop.equip(category,null);onEquip();refresh();document.getElementById('shop-message').textContent='기본 외형으로 돌아왔어요.';};
    dialog.querySelectorAll('[role=tab]').forEach(t=>{t.setAttribute('aria-selected',String(t.dataset.category===category));t.tabIndex=t.dataset.category===category?0:-1;});
  }
  function close(){dialog.close();}
  function toggle(){if(dialog.open){close();return;}if(!ready())return;onOpen();refresh();document.getElementById('shop-message').textContent='';dialog.showModal();}
  dialog.querySelectorAll('[role=tab]').forEach((tab,index)=>{tab.onclick=()=>{category=tab.dataset.category;refresh();};tab.onkeydown=e=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const n=e.key==='Home'?0:e.key==='End'?2:(index+(e.key==='ArrowRight'?1:2))%3;const next=dialog.querySelectorAll('[role=tab]')[n];next.click();next.focus();}};});
  button.onclick=toggle;document.getElementById('shop-close').onclick=close;
  dialog.addEventListener('close',onClose);dialog.addEventListener('cancel',e=>{e.preventDefault();close();});
  refresh();return {refresh,toggle,isOpen:()=>dialog.open};
}
