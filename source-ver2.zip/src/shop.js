import {STONE_REWARDS,SKIN_PRICE} from './settings.js';
export const REWARDS=STONE_REWARDS;
export const CATALOG=[
  {id:'candy',category:'background',tab:'배경',name:'사탕 나무 숲',description:'나무가 달콤한 사탕으로 바뀌어요.',price:SKIN_PRICE,model:'candy'},
  {id:'coconut',category:'weapon',tab:'무기',name:'코코넛',description:'손에 든 무기와 날아가는 탄환을 코코넛으로!',price:SKIN_PRICE,model:'coconut'},
  {id:'rabbit',category:'troop',tab:'군단',name:'토끼 원정대',description:'같은 힘, 새로운 모습. 토끼들과 함께 달려요.',price:SKIN_PRICE,model:'rabbit'},
];
export class Shop {
  constructor(raw,save=()=>{}){
    let data;try{data=JSON.parse(raw||'{}');}catch{data={};}data??={};
    this.stones=Number.isSafeInteger(data.stones)&&data.stones>=0?data.stones:0;
    this.owned=CATALOG.filter(i=>Array.isArray(data.owned)&&data.owned.includes(i.id)).map(i=>i.id);
    this.equipped={};for(const i of CATALOG)this.equipped[i.category]=this.owned.includes(i.id)&&data.equipped?.[i.category]===i.id?i.id:null;
    this.save=save;
  }
  persist(){this.save(JSON.stringify({stones:this.stones,owned:this.owned,equipped:this.equipped}));}
  reward(level){const amount=REWARDS[level]||0;this.stones+=amount;this.persist();return amount;}
  buy(id){const item=CATALOG.find(i=>i.id===id);if(!item||this.owned.includes(id)||this.stones<item.price)return false;this.stones-=item.price;this.owned.push(id);this.equipped[item.category]=id;this.persist();return true;}
  equip(category,id){if(id!==null&&!CATALOG.some(i=>i.category===category&&i.id===id&&this.owned.includes(id)))return false;if(!CATALOG.some(i=>i.category===category))return false;this.equipped[category]=id;this.persist();return true;}
}
