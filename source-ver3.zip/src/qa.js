// Development-only visual fixtures. Loaded only with ?qa=1 in Vite dev mode.
// They exercise the real renderer and simulation without writing user saves.
export function installQA(game,flush){
  const panel=document.createElement('nav');panel.setAttribute('aria-label','개발 검증');
  Object.assign(panel.style,{position:'fixed',bottom:'0',left:'0',zIndex:100,display:'flex',gap:'4px',padding:'6px',background:'#172d29',color:'white'});
  function button(name,action){const b=document.createElement('button');b.textContent=name;b.style.cssText='font-size:11px;padding:8px;border-radius:5px';b.onclick=()=>{action();flush();};panel.append(b);}
  function reset(stage){game.stage=stage;game.status='ready';game.start();}
  button('진화·스킬 확인',()=>{
    reset(3);game.changeTroop(100);game.weapon=2;game.leaves=9;
    game.events.forEach(e=>{if(e.level!==2){e.done=true;game.emit('removed',{id:e.id});}});
    const apples=game.events.filter(e=>e.type==='enemy'&&e.level<2).slice(0,2);
    apples.forEach((e,i)=>{e.done=false;e.z=-12-i*8;e.worldZ=e.z;e.x=i?-2:2;e.hp=e.maxHp=10000;});
    game.emit('setup');game.emit('troop');game.emit('leaves');
  });
  button('3단계 보스 확인',()=>{
    reset(3);game.changeTroop(100);game.weapon=2;game.leaves=7;
    game.events.forEach(e=>{if(e!==game.boss){e.done=true;game.emit('removed',{id:e.id});}});
    game.distance=game.endDistance;game.emit('troop');game.emit('leaves');
  });
  button('충돌 확인',()=>{
    reset(1);game.changeTroop(20);game.shotClock=10;
    game.events.forEach(e=>{if(e!==game.boss){e.done=true;game.emit('removed',{id:e.id});}});
    const e=game.events.find(e=>e.type==='enemy');e.done=false;e.z=-2;e.worldZ=-2;e.x=0;e.hp=50;e.maxHp=100;
    game.emit('setup');game.emit('troop');
  });
  button('나뭇잎 확인',()=>{
    reset(1);game.leaves=0;
    game.events.forEach(e=>{if(e!==game.boss){e.done=true;game.emit('removed',{id:e.id});}});
    game.events.filter(e=>e.type==='leaf').slice(0,7).forEach((e,i)=>{e.done=false;e.z=-3-i*2;e.worldZ=e.z;e.x=0;});
    game.emit('setup');game.emit('leaves');
  });
  button('일반 플레이',()=>{reset(1);});
  button('직진 사격 확인',()=>{
    reset(1);game.changeTroop(20);
    game.events.forEach(e=>{if(e!==game.boss){e.done=true;game.emit('removed',{id:e.id});}});
    game.events.filter(e=>e.type==='enemy'&&e.level<2).slice(0,3).forEach((e,i)=>{e.done=false;e.x=[0,3,-3][i];e.z=-18-i*3;e.worldZ=e.z;e.hp=e.maxHp=300;});
    game.emit('setup');game.emit('troop');
  });
  button('클리어 이미지 확인',()=>{reset(1);game.finish(true);});
  button('상점 보상 확인',()=>{reset(1);game.pause();game.events.filter(e=>e.type==='enemy'&&e.level<2).slice(0,16).forEach(e=>game.damage(e,e.maxHp));});
  document.body.append(panel);
}
