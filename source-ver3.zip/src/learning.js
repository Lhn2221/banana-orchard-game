import {CATALOG,REWARDS} from './shop.js';
export function learningUI({game,shop,flush,markLearned}){
  const tip=document.createElement('div');tip.id='lesson-tip';tip.setAttribute('role','status');document.getElementById('viewport').append(tip);
  const result=document.createElement('div');result.id='round-summary';result.hidden=true;document.getElementById('start').before(result);
  const retries=document.createElement('div');retries.id='retry-options';retries.hidden=true;
  for(const [same,text] of [[true,'같은 배치 재도전'],[false,'새 배치 도전']]){const b=document.createElement('button');b.textContent=text;b.onclick=()=>{game.retry(same);flush();};retries.append(b);}
  document.getElementById('start').after(retries);
  let earned=0,skillShown=false;
  function show(){
    const texts={move:'① 좌우로 움직여 보세요 · ← → / A D / 화면 드래그',gate:'② 오른쪽 초록 +12 문을 통과해 병력을 늘려요',attack:`③ 사과 앞에 서 보세요 · 공격은 자동! 파괴하면 돌멩이 +${REWARDS[0]}`};
    tip.hidden=!game.lesson||game.status!=='running';tip.replaceChildren();
    if(game.lesson){const span=document.createElement('span');span.textContent=texts[game.lesson];const skip=document.createElement('button');skip.textContent='안내 건너뛰기';skip.onclick=()=>{game.skipLesson();markLearned();flush();};tip.append(span,skip);}
  }
  return {signal(s){
    if(s.type==='setup'){earned=0;result.hidden=true;retries.hidden=true;document.getElementById('start').hidden=false;}
    if(s.type==='kill')earned+=REWARDS[s.level];
    if(s.type==='learned'){markLearned();document.getElementById('mission').textContent='연습 완료! 사과를 수확하고 S키 상점에서 스킨을 구매해보세요.';}
    if(s.type==='finished'){
      result.hidden=false;retries.hidden=false;
      const next=CATALOG.find(i=>!shop.owned.includes(i.id));
      result.textContent=`이번 판 돌멩이 +${earned} · 보유 ${shop.stones}개\n${next?(shop.stones>=next.price?`${next.name} 구매 가능! S키 상점`:`${next.name}까지 ${next.price-shop.stones}개`):'모든 스킨 수집 완료! 다른 모습으로 도전해보세요.'}`;
      document.getElementById('start').hidden=!s.win;
    }
    show();
    if(!game.lesson&&game.leaves>=7&&game.status==='running'&&!skillShown){skillShown=true;document.getElementById('mission').textContent='스킬 준비 완료! Space 또는 숲의 폭발 버튼으로 광역 공격';}
  }};
}
