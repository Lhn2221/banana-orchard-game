import {STONE_REWARDS} from './settings.js';
export const REWARDS=STONE_REWARDS;
export const CATALOG=[
  {id:'candy',category:'background',tab:'배경',name:'사탕 나무 숲',description:'나무가 달콤한 사탕으로 바뀌어요.',price:100,model:'candy'},
  {id:'icecream',category:'background',tab:'배경',name:'아이스크림 숲',description:'길가의 나무가 커다란 아이스크림으로 바뀌어요.',price:300,model:'icecream'},
  {id:'seaweed',category:'background',tab:'배경',name:'미역 바다 숲',description:'길가를 푸른 미역과 바위가 장식해요.',price:1000,model:'seaweed'},
  {id:'coconut',category:'weapon',tab:'무기',name:'코코넛',description:'손에 든 무기와 날아가는 탄환을 코코넛으로!',price:100,model:'coconut'},
  {id:'carrot',category:'weapon',tab:'무기',name:'당근',description:'바나나 대신 주황빛 당근을 발사해요.',price:300,model:'carrot'},
  {id:'starfish',category:'weapon',tab:'무기',name:'불가사리',description:'바닷속 불가사리를 일직선으로 발사해요.',price:1000,model:'starfish'},
  {id:'rabbit',category:'troop',tab:'군단',name:'토끼 원정대',description:'같은 힘, 새로운 모습. 토끼들과 함께 달려요.',price:100,model:'rabbit'},
  {id:'gingerbread',category:'troop',tab:'군단',name:'진저맨 쿠키 원정대',description:'달콤한 진저브레드맨들이 원정에 나서요.',price:300,model:'gingerbread'},
  {id:'seahorse',category:'troop',tab:'군단',name:'해마 원정대',description:'바닷빛 해마들이 같은 힘으로 함께 달려요.',price:1000,model:'seahorse'},
];
export class Shop {
  constructor(raw,save=()=>{}){
    let data;try{data=JSON.parse(raw||'{}');}catch{data={};}data??={};
    this.stones=Number.isSafeInteger(data.stones)&&data.stones>=0?data.stones:0;
    this.owned=CATALOG.filter(i=>Array.isArray(data.owned)&&data.owned.includes(i.id)).map(i=>i.id);
    this.equipped={};for(const category of new Set(CATALOG.map(i=>i.category))){const id=data.equipped?.[category];this.equipped[category]=CATALOG.some(i=>i.category===category&&i.id===id&&this.owned.includes(id))?id:null;}
    this.save=save;
  }
  persist(){this.save(JSON.stringify({stones:this.stones,owned:this.owned,equipped:this.equipped}));}
  reward(level){const amount=REWARDS[level]||0;this.stones+=amount;this.persist();return amount;}
  buy(id){const item=CATALOG.find(i=>i.id===id);if(!item||this.owned.includes(id)||this.stones<item.price)return false;this.stones-=item.price;this.owned.push(id);this.equipped[item.category]=id;this.persist();return true;}
  equip(category,id){if(id!==null&&!CATALOG.some(i=>i.category===category&&i.id===id&&this.owned.includes(id)))return false;if(!CATALOG.some(i=>i.category===category))return false;this.equipped[category]=id;this.persist();return true;}
}
