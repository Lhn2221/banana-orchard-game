import {makeStage,formation,evolutionFor,rosterPower,mergeRoster,gateRoster,EVOLUTIONS,WEAPONS,frontRowOffsets,gateContains,projectileHitTime,collisionSurvivors,touchedUnits,spendLeaves,blastHp,readLeaves,STAGE_COUNT,BOSS_SECONDS,ENEMIES} from './rules.js';

import {INITIAL_TROOPS,RUN_SPEED,SHOT_INTERVAL,PROJECTILE_SPEED} from './settings.js';

// 화면과 입력에 의존하지 않는 게임 규칙입니다. update(dt)가 시간을 진행합니다.
export class Game {
  constructor({leaves=0,saveLeaves=()=>{},random=Math.random}={}){
    this.leaves=readLeaves(leaves);this.saveLeaves=saveLeaves;this.random=random;
    this.signals=[];this.stage=1;this.status='ready';this.setup();
  }
  emit(type,detail={}){this.signals.push({type,...detail});}
  drain(){return this.signals.splice(0);}
  setup(same=false){
    this.count=INITIAL_TROOPS;this.roster=Array(INITIAL_TROOPS).fill(0);this.rank=0;this.weapon=0;this.distance=0;this.x=0;this.targetX=0;
    this.shotClock=0;this.bossTime=BOSS_SECONDS;this.bossActive=false;this.kills=0;
    this.projectiles=[];this.nextShotId=0;
    if(!same||!this.route){
      this.route=makeStage(this.stage,this.random);
      if(this.teaching){
        const gate=this.route.find(e=>e.type==='gate'),apple=this.route.find(e=>e.type==='enemy'&&e.level<2);
        Object.assign(gate,{z:-8,x:1.8,op:'+',value:12,lesson:true});
        Object.assign(apple,{z:-24,x:1.8,level:0,hp:20,approach:0,speed:0,lesson:true});
        this.route.sort((a,b)=>b.z-a.z);
      }
    }
    this.lesson=this.teaching?'move':null;
    this.events=this.route.map((e,id)=>({...e,id,done:false,maxHp:e.hp,worldZ:e.z}));
    this.boss=this.events.at(-1);this.endDistance=-7-this.boss.z;
    this.emit('setup');this.emit('troop');this.emit('leaves');
  }
  get units(){return this.roster;}
  get power(){return rosterPower(this.roster,this.weapon);}
  start(){
    if(this.status==='paused'){this.pause();return;}
    if(this.status==='running')return;
    if(this.status==='won')this.stage=this.stage===STAGE_COUNT?1:this.stage+1;
    this.setup();this.status='running';this.emit('started');
  }
  retry(same=true){if(!['lost','won'].includes(this.status))return;this.teaching=false;this.setup(same);this.status='running';this.emit('started');}
  skipLesson(){this.lesson=null;this.teaching=false;this.emit('lesson');}
  pause(){if(this.status==='running'){this.status='paused';this.emit('paused');}else if(this.status==='paused'){this.status='running';this.emit('started');}}
  changeTroop(count){
    this.setUnits(formation(count,evolutionFor(count,this.rank)));
  }
  setUnits(units){
    this.roster=mergeRoster(units);this.count=this.roster.reduce((sum,r)=>sum+EVOLUTIONS[r].weight,0);
    const rank=Math.max(this.rank,...this.roster);
    if(rank>this.rank)this.emit('evolved',{rank});
    this.rank=rank;this.emit('troop');
    if(this.count<=0)this.finish(false,'원숭이 부대가 모두 사라졌어요.');
  }
  finish(win,reason=''){
    if(this.status!=='running')return;
    this.status=win?'won':'lost';this.emit('finished',{win,reason});
  }
  remove(e){e.done=true;this.emit('removed',{id:e.id});}
  damage(e,amount){
    if(e.done)return;
    const dealt=Math.min(e.hp,amount);e.hp=Math.max(0,e.hp-amount);this.emit('hit',{id:e.id,amount:dealt});
    if(e.hp===0&&e.lesson&&this.lesson){this.skipLesson();this.emit('learned');}
    if(e.hp<=0){this.remove(e);this.kills++;this.emit('kill',{level:e.level});if(e.level===2)this.finish(true);}
  }
  activeEnemies(range=50){return this.events.filter(e=>!e.done&&e.type==='enemy'&&e.worldZ>=-range&&e.worldZ<=5&&(e.level!==2||this.bossActive));}
  blast(){
    if(this.status!=='running')return false;
    const spent=spendLeaves(this.leaves);if(!spent.used)return false;
    this.leaves=spent.leaves;this.saveLeaves(this.leaves);this.emit('leaves');
    const targets=this.activeEnemies();this.emit('blast',{hits:targets.length});
    for(const e of targets)this.damage(e,e.hp-blastHp(e.hp,e.maxHp));
    return true;
  }
  fire(){
    if(this.lesson==='move'||this.lesson==='gate')return;
    const offsets=frontRowOffsets(this.units.length);
    const shots=offsets.map((offset,column)=>({id:this.nextShotId++,x:this.x+offset,z:1,weapon:this.weapon,damage:this.units.reduce((sum,rank,i)=>sum+(i%6===column?EVOLUTIONS[rank].weight*EVOLUTIONS[rank].bonus*WEAPONS[this.weapon].damage:0),0),dead:false}));
    this.projectiles.push(...shots);this.emit('shot',{shots});
  }
  advanceProjectiles(dt){
    const targets=this.activeEnemies(52);
    for(const p of this.projectiles){
      const oldZ=p.z;p.z-=PROJECTILE_SPEED*dt;let hit=null,time=Infinity;
      for(const e of targets){if(e.done)continue;const t=projectileHitTime(p,oldZ,p.z,e);if(t!==null&&t<time){time=t;hit=e;}}
      if(hit){p.dead=true;this.damage(hit,p.damage);}else if(p.z< -48)p.dead=true;
      if(this.status!=='running')break;
    }
    this.projectiles=this.projectiles.filter(p=>!p.dead);
  }
  update(dt){
    if(this.status!=='running')return;
    dt=Math.max(0,Math.min(dt,.05));
    this.targetX=Math.max(-3.2,Math.min(3.2,this.targetX));
    this.x+=(this.targetX-this.x)*(1-Math.exp(-12*dt));
    let advance=dt*RUN_SPEED;
    if(this.lesson==='move'){advance=0;if(Math.abs(this.x)>.5){this.lesson='gate';this.emit('lesson');}}
    if(this.lesson==='gate'){const gate=this.events.find(e=>e.lesson&&e.type==='gate');if(gate&&!gate.done&&!gateContains(gate,this.x))advance=Math.min(advance,Math.max(0,1-gate.z-this.distance));}
    if(this.lesson==='attack'){const apple=this.events.find(e=>e.lesson&&e.type==='enemy');if(apple&&!apple.done)advance=Math.min(advance,Math.max(0,-10-apple.z-this.distance));}
    this.distance=Math.min(this.endDistance,this.distance+advance);
    for(const e of this.events){
      if(e.done)continue;
      e.previousZ=e.worldZ;
      if(e.type==='enemy'&&e.level<2&&e.z+this.distance>-50)e.approach+=dt*e.speed;
      e.worldZ=e.z+this.distance+(e.approach||0);
    }
    if(!this.bossActive&&this.distance>=this.endDistance){this.bossActive=true;this.emit('boss');}
    // At an exact timeout, time expires before a new shot can be fired.
    if(this.bossActive){this.bossTime=Math.max(0,this.bossTime-dt);if(this.bossTime===0){this.finish(false,'보스 제한 시간 30초가 지났어요.');return;}}
    this.advanceProjectiles(dt);if(this.status!=='running')return;
    for(const e of this.events){
      if(e.done)continue;
      if(e.type==='gate'&&e.worldZ>=1.2){
        const {op,value}=e,before=this.units.length;this.remove(e);
        if(gateContains(e,this.x)){this.setUnits(gateRoster(this.units,op,value));this.emit('gate',{op,value,before,after:this.units.length});if(e.lesson&&this.lesson){this.lesson='attack';this.emit('lesson');}}
      }else if(e.type==='item'&&e.worldZ>=1.2){
        this.weapon=e.tier;this.remove(e);this.emit('troop');this.emit('weapon');
      }else if(e.type==='leaf'&&e.worldZ>=.8){
        if(e.worldZ<=4.8&&Math.abs(e.x-this.x)<1.3){this.leaves++;this.saveLeaves(this.leaves);this.remove(e);this.emit('leaves');this.emit('pickup');}
        else if(e.worldZ>4.8)this.remove(e);
      }else if(e.type==='enemy'&&e.level<2&&e.worldZ>=1.2){
        const touched=touchedUnits(e.x,e.worldZ,ENEMIES[e.level].size,this.x,this.units.length);
        if(e.worldZ<=5&&touched.length){
          const survivors=collisionSurvivors(touched.length,e.hp,e.maxHp),lost=touched.length-survivors;
          const removed=new Set(touched.slice(survivors));
          this.remove(e);this.setUnits(this.units.filter((_,i)=>!removed.has(i)));this.emit('collision',{lost,fraction:e.hp/e.maxHp});
        }else if(e.worldZ>5)this.remove(e);
      }
      if(this.status!=='running')return;
    }
    this.shotClock-=dt;
    if(this.shotClock<=0){this.shotClock=SHOT_INTERVAL;this.fire();}
  }
}
