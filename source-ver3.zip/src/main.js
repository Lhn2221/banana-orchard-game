import './style.css';
import './shop.css';
import './v2.css';
import './mobile.css';
import {learningUI} from './learning.js';
import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {clone} from 'three/addons/utils/SkeletonUtils.js';
import {Game} from './game.js';
import {Shop,CATALOG} from './shop.js';
import {installShop} from './shop-ui.js';
import {makeVictoryPortrait} from './portrait.js';
import {WEAPONS,EVOLUTIONS,ENEMIES,THEMES,STAGE_COUNT,LEAF_COST,readLeaves} from './rules.js';

const $=id=>document.getElementById(id),view=$('viewport'),canvas=$('game');
const scene=new THREE.Scene();scene.background=new THREE.Color('#b8ce91');scene.fog=new THREE.Fog('#b8ce91',35,95);
const camera=new THREE.PerspectiveCamera(43,1,.1,150);camera.position.set(0,15,19);camera.lookAt(0,0,-14);
let renderer;
try{renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});}
catch(e){$('load-status').textContent='WebGL을 사용할 수 없습니다. 하드웨어 가속을 켜고 다시 열어주세요.';throw e;}
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.shadowMap.enabled=true;
renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;
const ambient=new THREE.HemisphereLight(0xffffe7,0x73864c,2.7);scene.add(ambient);
const troopLight=new THREE.PointLight(0xffe9aa,0,18,2);troopLight.position.set(0,3,3);scene.add(troopLight);
const sun=new THREE.DirectionalLight(0xfff0c9,3);sun.position.set(-12,24,12);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);
Object.assign(sun.shadow.camera,{left:-18,right:18,top:30,bottom:-25});sun.shadow.bias=-.001;scene.add(sun);
function plane(w,h,color){const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshStandardMaterial({color,roughness:1}));m.rotation.x=-Math.PI/2;m.receiveShadow=true;return m;}
const field=plane(200,250,0xa8c477);field.position.set(0,-.03,-70);scene.add(field);
const road=plane(10,250,0xd9c698);road.position.z=-70;scene.add(road);
for(const x of [-4.85,4.85]){const p=plane(.15,250,0xf4e2b5);p.position.set(x,.012,-70);scene.add(p);}
const models={},weaponVariants={banana:[],coconut:[],carrot:[],starfish:[]},troopVariants={monkey:[],rabbit:[],gingerbread:[],seahorse:[]},scenery=[],monkeys=[],projectiles=[],labels=[],eventViews=new Map();
const world=new THREE.Group(),troop=new THREE.Group();scene.add(world,troop);
const sphereGeometry=new THREE.SphereGeometry(.67,16,12);
const sphereMaterial=new THREE.MeshPhysicalMaterial({color:0xbdfce6,transparent:true,opacity:.3,roughness:.12,metalness:.05,depthWrite:false});
const burstGeometry=new THREE.RingGeometry(.8,1,64),burstMaterial=new THREE.MeshBasicMaterial({color:0xbfffd7,transparent:true,opacity:0,side:THREE.DoubleSide,depthWrite:false});
const burst=new THREE.Mesh(burstGeometry,burstMaterial);burst.rotation.x=-Math.PI/2;burst.position.y=.2;scene.add(burst);
const qaMode=import.meta.env.DEV&&new URLSearchParams(location.search).has('qa');
let shopRaw;try{if(!qaMode)shopRaw=localStorage.getItem('orchard-shop');}catch{}
const shop=new Shop(shopRaw,s=>{try{if(!qaMode)localStorage.setItem('orchard-shop',s);}catch{}}),previews={};
let shopUI,learning,resumeAfterShop=false,tutorialDone=false;
try{tutorialDone=!qaMode&&localStorage.getItem('orchard-v2-learned')==='1';}catch{}
const versionBadge=document.createElement('span');versionBadge.className='version-badge';versionBadge.textContent='ver.3';document.querySelector('.brand').append(versionBadge);
let game,ready=false,elapsed=0,toastTime=0,burstTime=0,best=0,sound=false,audioCtx,leafTemplate;
let savedLeaves=0;
try{if(!qaMode){best=Math.max(0,Math.min(STAGE_COUNT,Number(localStorage.getItem('orchard-best'))||0));savedLeaves=readLeaves(localStorage.getItem('orchard-leaves'));}}catch{}
$('best').textContent=best?`최고 기록 ${best} 스테이지`:'최고 기록 —';
function tone(freq=440,duration=.09){if(!sound)return;try{audioCtx??=new AudioContext();audioCtx.resume();const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.frequency.value=freq;g.gain.setValueAtTime(.025,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);o.connect(g).connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+duration);}catch{}}
function toast(text){$('toast').textContent=text;$('toast').style.opacity=1;toastTime=2;}
function normalize(obj,size){
  obj.updateMatrixWorld(true);const box=new THREE.Box3().setFromObject(obj),s=box.getSize(new THREE.Vector3());
  const g=new THREE.Group();g.add(obj);obj.scale.multiplyScalar(size/Math.max(s.x,s.y,s.z));obj.updateMatrixWorld(true);
  const b=new THREE.Box3().setFromObject(obj),c=b.getCenter(new THREE.Vector3());obj.position.x-=c.x;obj.position.z-=c.z;obj.position.y-=b.min.y;
  obj.traverse(n=>{if(n.isMesh){n.castShadow=true;n.receiveShadow=true;}});return g;
}
function instance(name,size){return normalize(clone(models[name].scene),size);}
function weaponModel(t,size){const skin=shop.equipped.weapon||'banana';return normalize(clone(weaponVariants[skin][t]),size);}
function rainbowMaterial(material){
  material.map=null;material.color.set('#ffffff');
  material.onBeforeCompile=shader=>{
    shader.vertexShader='varying vec3 rainbowPosition;\n'+shader.vertexShader.replace('#include <project_vertex>','rainbowPosition = (modelMatrix * vec4(transformed, 1.0)).xyz;\n#include <project_vertex>');
    shader.fragmentShader='varying vec3 rainbowPosition;\n'+shader.fragmentShader.replace('#include <color_fragment>','#include <color_fragment>\ndiffuseColor.rgb = 0.5 + 0.5 * cos(rainbowPosition.y * 8.0 + vec3(0.0, 2.1, 4.2));');
  };material.customProgramCacheKey=()=>'orchard-rainbow';
}
function prepareMaterials(){
  models.monkey.scene.traverse(n=>{if(n.isMesh){const m=n.material;m.metalness=0;m.roughness=.85;if(m.name==='Monkroose_Main')m.color.set('#86532f');if(m.name==='Monkroose_Ears'||m.name==='Monkroose_Secondary')m.color.set('#d5aa76');if(m.name==='Eye_White')m.color.set('#fff6de');}});
  for(let rank=0;rank<3;rank++){
    for(const name of Object.keys(troopVariants)){const obj=clone(models[name].scene);obj.traverse(n=>{if(n.isMesh){n.material=n.material.clone();if(!n.material.name.startsWith('Eye')){if(rank===1){n.material.map=null;n.material.color.set('#ffc94b');n.material.metalness=.35;}if(rank===2)rainbowMaterial(n.material);}}});troopVariants[name].push(obj);}
    for(const name of Object.keys(weaponVariants)){const obj=clone(models[name].scene);obj.traverse(n=>{if(n.isMesh){n.material=n.material.clone();if(rank===1){n.material.map=null;n.material.color.set('#438eff');n.material.metalness=.15;}if(rank===2)rainbowMaterial(n.material);}});weaponVariants[name].push(obj);}
  }
  // Reuse the leaf geometry already supplied with the user's apple, without new modeling.
  models.apple.scene.traverse(n=>{if(n.isMesh&&/leaf/i.test(n.name))leafTemplate=n;});
  if(!leafTemplate)throw new Error('Apple leaf mesh missing');
}
function label(parent,text,css,y){const el=document.createElement('div');el.className=`world-label ${css}`;el.innerHTML=text;$('labels').append(el);labels.push({parent,el,y});return el;}
function releaseMonkey(m){m.userData.mixer?.stopAllAction();m.userData.mixer?.uncacheRoot(m);troop.remove(m);}
function syncTroop(){
  const units=game.units;
  for(let i=0;i<Math.max(units.length,monkeys.length);i++){
    if(monkeys[i]&&monkeys[i].userData.rank!==units[i]){releaseMonkey(monkeys[i]);monkeys[i]=null;}
    if(i<units.length&&!monkeys[i]){
      const skin=shop.equipped.troop||'monkey';
      const m=normalize(clone(troopVariants[skin][units[i]]),1.12);m.rotation.y=Math.PI;m.userData.rank=units[i];m.userData.skin=skin;m.userData.hopPhase=i*.72;
      const clip=models[skin].animations.find(a=>/run/i.test(a.name));
      if(clip){m.userData.mixer=new THREE.AnimationMixer(m);m.userData.mixer.clipAction(clip).play();}
      troop.add(m);monkeys[i]=m;
    }
  }
  monkeys.length=units.length;
  monkeys.forEach((m,i)=>{
    const row=Math.floor(i/6),cols=Math.min(6,units.length-row*6);m.userData.baseX=(i%6-(cols-1)/2)*.52;m.userData.baseZ=row*.58;
    if(m.userData.weaponTier!==game.weapon){if(m.userData.weapon)m.remove(m.userData.weapon);const held=weaponModel(game.weapon,.35);held.position.set(-.42,.6,0);held.rotation.z=-.6;m.add(held);m.userData.weapon=held;m.userData.weaponTier=game.weapon;}
  });
  $('count').innerHTML=`${units.length}<span>마리</span>`;
  $('evolution').textContent=`${EVOLUTIONS[game.rank].name} · 환산 병력 ${game.count}`;
  $('weapon').innerHTML=`${WEAPONS[game.weapon].name}<span>×${WEAPONS[game.weapon].damage}</span>`;
  $('weapon').style.color=['#9a8436','#558ac0','#a570b0'][game.weapon];$('power').textContent=game.power;
}
function addEvent(e){
  let obj,el;
  if(e.type==='gate'){
    obj=new THREE.Group();
    const mesh=new THREE.Mesh(new THREE.PlaneGeometry(e.width,2.6),new THREE.MeshBasicMaterial({color:e.op==='+'||e.op==='×'?0x38c263:0xe65d56,transparent:true,opacity:.6,side:THREE.DoubleSide,depthWrite:false}));
    mesh.position.y=1.3;obj.add(mesh);label(obj,`${e.op} ${e.value}`,'gate-label',2.2);
  }else if(e.type==='enemy'){
    const spec=ENEMIES[e.level];obj=instance('apple',spec.size);obj.rotation.y=.4;
    obj.traverse(n=>{if(n.isMesh){n.material=n.material.clone();n.material.userData.hitClone=true;}});
    if(e.crowned){const crown=instance('crown',2.35);crown.position.y=spec.size*.72;obj.add(crown);}
    if(e.level<2)el=label(obj,`Lv.${e.level+1} ${spec.name}<br><span></span><div class="bar"><i></i></div>`,'enemy-label',spec.size+.5);
  }else if(e.type==='item'){
    obj=weaponModel(e.tier,1.7);label(obj,`${WEAPONS[e.tier].name} 바나나 ↑`,'item-label',2);
  }else{
    obj=new THREE.Group();obj.add(new THREE.Mesh(sphereGeometry,sphereMaterial));
    const leaf=normalize(leafTemplate.clone(),.95);leaf.position.y=-.25;leaf.rotation.set(.6,0,.3);obj.add(leaf);
    label(obj,'+1 잎','leaf-label',1);
  }
  obj.position.set(e.x,e.type==='leaf'?1.1:0,e.z);obj.visible=!e.done;world.add(obj);eventViews.set(e.id,{obj,el});if(el)updateHp(e);
}
function updateHp(e){const el=eventViews.get(e.id)?.el;if(!el)return;el.querySelector('span').textContent=`${Math.ceil(e.hp)} / ${e.maxHp}`;el.querySelector('i').style.width=`${e.hp/e.maxHp*100}%`;}
function applyTheme(){
  const theme=THEMES[game.stage-1];scene.background.set(theme.sky);scene.fog.color.set(theme.sky);field.material.color.set(theme.ground);road.material.color.set(theme.road);
  ambient.intensity=theme.ambient;ambient.color.set(theme.light);sun.intensity=theme.sun;sun.color.set(theme.light);
  troopLight.intensity=(game.stage-1)*3;
  document.body.style.setProperty('--stage-tint',theme.sky);
  scenery.forEach(s=>{scene.remove(s.obj);s.obj.traverse(n=>{if(n.isMesh)n.material.dispose();});});scenery.length=0;
  for(const [name,amount] of [['tree',theme.trees],['fence',theme.fences]])for(let i=0;i<amount;i++){
    const background=shop.equipped.background,obj=instance(name==='tree'&&background?(background==='icecream'?'icecream':background):name,name==='tree'?3.4+(i%4)*.4:1.9),side=i%2?1:-1;
    obj.position.x=side*(name==='tree'?7.8+(i%4)*1.5:5.7);if(name==='fence')obj.rotation.y=Math.PI/2;
    obj.traverse(n=>{if(n.isMesh){n.material=n.material.clone();n.material.color.multiply(new THREE.Color(theme.tint));}});
    scene.add(obj);scenery.push({obj,z:-Math.floor(i/2)*(110/Math.ceil(amount/2))});
  }
}
function setupView(){
  for(const v of eventViews.values()){v.damageEl?.remove();v.obj.traverse(n=>{if(n.isMesh&&n.material.userData.hitClone)n.material.dispose();});}
  for(const {obj} of eventViews.values())obj.traverse(n=>{if(n.isMesh&&n.geometry.type==='PlaneGeometry'){n.geometry.dispose();n.material.dispose();}});
  world.clear();eventViews.clear();labels.forEach(l=>l.el.remove());labels.length=0;
  projectiles.forEach(p=>scene.remove(p.obj));projectiles.length=0;
  $('toast').style.opacity=0;toastTime=0;$('boss-hud').hidden=true;$('victory-image').hidden=true;$('clear-stats').hidden=true;
  burstTime=0;burstMaterial.opacity=0;$('blast-flash').style.opacity=0;
  game.events.forEach(addEvent);applyTheme();
  $('stage-label').textContent=`STAGE 0${game.stage} / 0${STAGE_COUNT}`;$('stage-title').textContent=`0${game.stage} ${THEMES[game.stage-1].name}`;
  document.querySelectorAll('.route i').forEach((n,i)=>n.classList.toggle('active',i<game.stage));
  $('progress-fill').style.width='0%';$('harvest').textContent='수확 0';$('mission').textContent='사과를 피하며 초록 문과 나뭇잎을 모으세요';
}
function skillUI(){
  const charged=game.leaves>=LEAF_COST;$('leaf-count').textContent=`${game.leaves} / ${LEAF_COST} 잎`;
  $('leaf-pips').innerHTML=Array.from({length:7},(_,i)=>`<i class="${i<game.leaves?'filled':''}"></i>`).join('');
  $('blast').disabled=!charged||game.status!=='running';$('blast').classList.toggle('charged',charged);
  $('blast').querySelector('small').textContent=charged?`Space · ${Math.floor(game.leaves/7)}회 사용 가능`:`${7-game.leaves} 잎 더 모으세요`;
}
function overlay(tag,title,desc,button){
  $('overlay-tag').textContent=tag;$('overlay-title').textContent=title;$('overlay-desc').innerHTML=desc;$('start').textContent=button;
  $('load-status').textContent='← → / A D · Space 폭발 · P 일시정지';$('overlay').classList.remove('hidden');
}
function shootVisual(s){
  for(const shot of s.shots){
    const obj=weaponModel(shot.weapon,.42);obj.position.set(shot.x,.75,shot.z);scene.add(obj);
    projectiles.push({obj,shot});
  }tone(300+game.weapon*180,.04);
}
function handleSignals(){
  for(const s of game.drain()){
    switch(s.type){
      case 'setup':setupView();break;
      case 'troop':syncTroop();break;
      case 'leaves':skillUI();break;
      case 'started':$('overlay').classList.add('hidden');$('pause').textContent='일시정지';skillUI();break;
      case 'paused':$('victory-image').hidden=true;$('clear-stats').hidden=true;overlay('TAKE A LITTLE BREAK','잠깐 쉬어가요','스킬과 보스 제한 시간도 잠시 멈췄어요.','계속하기');$('pause').textContent='계속하기';skillUI();break;
      case 'removed':{const v=eventViews.get(s.id);if(v)v.obj.visible=false;break;}
      case 'hit':{const e=game.events.find(e=>e.id===s.id),v=eventViews.get(s.id);if(!e||!v)break;updateHp(e);v.flash=.15;v.damageTotal=(v.damageTime>0?v.damageTotal:0)+s.amount;v.damageTime=.65;if(!v.damageEl){v.damageEl=document.createElement('div');v.damageEl.className='damage-number';view.append(v.damageEl);}v.damageEl.textContent=`−${Math.round(v.damageTotal*10)/10}`;break;}
      case 'shot':shootVisual(s);break;
      case 'gate':{const calculated=s.op==='+'?s.before+s.value:s.op==='×'?s.before*s.value:s.op==='−'?Math.max(0,s.before-s.value):Math.floor(s.before/s.value);toast(`${s.before} ${s.op} ${s.value} = ${calculated}${calculated!==s.after?` → 합체·상한 적용 ${s.after}마리`:'마리'}`);tone(s.op==='+'||s.op==='×'?640:220);break;}
      case 'evolved':toast(`${EVOLUTIONS[s.rank].name} 원숭이 진화! 3 → 1 합체`);tone(900,.2);break;
      case 'weapon':toast(`${WEAPONS[game.weapon].name} 바나나! 공격력 ×${WEAPONS[game.weapon].damage}`);tone(950,.2);break;
      case 'pickup':toast(`나뭇잎 +1 · ${game.leaves} / 7`);tone(780,.05);break;
      case 'collision':toast(`사과 충돌! 남은 HP ${Math.round(s.fraction*100)}% · 원숭이 −${s.lost}마리`);tone(170,.15);break;
      case 'kill':{const reward=shop.reward(s.level);shopUI.refresh();$('harvest').textContent=`수확 ${game.kills}`;toast(`${s.level===2?'사과 왕 처치!':'사과 수확!'} 돌멩이 +${reward}`);break;}
      case 'boss':$('boss-hud').hidden=false;$('mission').textContent='보스전 · 30초 안에 사과 왕을 처치하세요';tone(240,.2);break;
      case 'blast':burstTime=.85;burst.position.z=-12;toast(`숲의 폭발! 사과 ${s.hits}마리에 광역 피해`);tone(120,.4);break;
      case 'finished':
        $('mission').textContent=s.win?'사과 왕 처치 · 원정 완료!':'원정 종료 · 다시 도전해보세요';
        if(s.win){
          best=Math.max(best,game.stage);try{if(!qaMode)localStorage.setItem('orchard-best',String(best));}catch{}
          $('best').textContent=`최고 기록 ${best} 스테이지`;$('victory-image').hidden=false;$('clear-stats').hidden=false;
          const counts=[0,0,0];game.units.forEach(r=>counts[r]++);
          $('clear-stats').innerHTML=`<strong>총 원숭이 ${game.units.length}마리</strong><span>일반 ${counts[0]} · 황금 ${counts[1]} · 무지개 ${counts[2]}</span><small>합체 전 환산 병력 ${game.count} · 보관 나뭇잎 ${game.leaves}</small>`;
          overlay('HARVEST COMPLETE',game.stage===STAGE_COUNT?'세 숲의 영웅!':'정말 잘했어요!',`스테이지 ${game.stage} 완료 · 사과 ${game.kills}마리 수확`,game.stage===STAGE_COUNT?'처음부터 다시':'다음 스테이지 →');tone(880,.3);
        }else{$('victory-image').hidden=true;$('clear-stats').hidden=true;overlay('TRY ANOTHER ROUTE','다시 모여, 원정대!',`${s.reason}<br>나뭇잎 ${game.leaves}개는 그대로 보관됩니다.`,'다시 도전');tone(180,.3);}
        skillUI();break;
    }
    learning?.signal(s);
  }
}
$('start').onclick=()=>{if(ready){if(game.status==='ready')game.teaching=!tutorialDone;game.start();handleSignals();tone(540);}};
$('pause').onclick=()=>{game?.pause();if(ready)handleSignals();};
$('blast').onclick=()=>{if(ready){game.blast();handleSignals();}};
$('sound').onclick=()=>{sound=!sound;$('sound').textContent=`소리 ${sound?'ON':'OFF'}`;$('sound').setAttribute('aria-label',sound?'소리 끄기':'소리 켜기');tone();};
$('credits').onclick=()=>{if(game?.status==='running'){game.pause();handleSignals();}$('credit-dialog').showModal();};$('close-credits').onclick=()=>$('credit-dialog').close();
const keys=new Set();
shopUI=installShop(shop,{ready:()=>ready,previews,onOpen:()=>{keys.clear();resumeAfterShop=game.status==='running';if(resumeAfterShop){game.pause();handleSignals();}},onClose:()=>{keys.clear();if(resumeAfterShop&&game.status==='paused'){game.pause();handleSignals();}resumeAfterShop=false;},onEquip:()=>{
  monkeys.forEach(releaseMonkey);monkeys.length=0;syncTroop();applyTheme();
  for(const p of projectiles){scene.remove(p.obj);p.obj=weaponModel(p.shot.weapon,.42);p.obj.position.set(p.shot.x,.75,p.shot.z);scene.add(p.obj);}
  for(const e of game.events)if(e.type==='item'){const v=eventViews.get(e.id);v.obj.clear();v.obj.add(weaponModel(e.tier,1.7));}
}});
addEventListener('keydown',e=>{
  if(!ready||$('credit-dialog').open)return;
  const key=e.key.toLowerCase();
  if(key==='s'){e.preventDefault();if(!e.repeat)shopUI.toggle();return;}
  if(shopUI.isOpen())return;
  if(['arrowleft','arrowright','a','d',' ','p','escape'].includes(key)){
    e.preventDefault();keys.add(key);
    if(!e.repeat){if(key===' ')game.blast();if(key==='p'||key==='escape')game.pause();handleSignals();}
  }
});
addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));
function unfocus(){keys.clear();if(game?.status==='running'){game.pause();handleSignals();}}
addEventListener('blur',unfocus);document.addEventListener('visibilitychange',()=>{if(document.hidden)unfocus();});
let dragging=false;
function point(e){if(!ready||game.status!=='running')return;const r=canvas.getBoundingClientRect();game.targetX=THREE.MathUtils.clamp(((e.clientX-r.left)/r.width-.5)*10,-3.2,3.2);}
canvas.addEventListener('pointerdown',e=>{dragging=true;canvas.setPointerCapture(e.pointerId);point(e);});canvas.addEventListener('pointermove',e=>{if(dragging)point(e);});canvas.addEventListener('pointerup',()=>dragging=false);canvas.addEventListener('pointercancel',()=>dragging=false);

function update(dt){
  if(!ready){renderer.render(scene,camera);return;}
  const running=game.status==='running';if(running){elapsed+=dt;if(keys.has('arrowleft')||keys.has('a'))game.targetX-=dt*6;if(keys.has('arrowright')||keys.has('d'))game.targetX+=dt*6;}
  game.update(dt);handleSignals();
  if(toastTime>0){toastTime-=dt;if(toastTime<=0)$('toast').style.opacity=0;}
  for(const e of game.events){const v=eventViews.get(e.id);if(e.done)continue;v.obj.position.z=e.worldZ;
    if(e.type==='leaf'||e.type==='item'){v.obj.rotation.y=elapsed*1.5;v.obj.position.y=(e.type==='leaf'?1.1:.7)+Math.sin(elapsed*3+e.id)*.16;}
    if(e.type==='enemy'&&e.level<2)v.obj.rotation.z=Math.sin(elapsed*2+e.id)*.04;
  }
  troop.position.x=game.x;monkeys.forEach(m=>{
    if(running)m.userData.mixer?.update(dt);
    const skin=m.userData.skin,step=elapsed*5.4+m.userData.hopPhase,seahorse=skin==='seahorse';
    const hop=seahorse?Math.abs(Math.sin(step))*.42:0;
    m.position.set(m.userData.baseX,hop,1.2+m.userData.baseZ);
    m.rotation.x=0;m.rotation.z=seahorse?Math.sin(step)*.12:0;
  });
  for(let i=projectiles.length-1;i>=0;i--){const p=projectiles[i];p.obj.position.set(p.shot.x,.75,p.shot.z);if(running)p.obj.rotation.z+=dt*10;if(p.shot.dead){scene.remove(p.obj);projectiles.splice(i,1);}}
  troopLight.position.x=game.x;
  if(burstTime>0&&running)burstTime=Math.max(0,burstTime-dt);
  const burstAge=1-burstTime/.85;burst.scale.setScalar(1+burstAge*48);burstMaterial.opacity=burstTime>0?(1-burstAge)*.8:0;$('blast-flash').style.opacity=burstTime>0?String((1-burstAge)*.6):'0';
  scenery.forEach(s=>{s.obj.position.z=((s.z+game.distance+25)%115+115)%115-85;});
  const progress=Math.min(100,game.distance/game.endDistance*100);$('progress-fill').style.width=`${progress}%`;$('stage-distance').textContent=`${Math.floor(progress)}%`;
  if(game.bossActive){$('boss-name').textContent=game.stage===STAGE_COUNT?'♛ FINAL BOSS · 왕관의 사과 왕':'BOSS · 사과 왕';$('boss-timer').textContent=`${game.bossTime.toFixed(1)}초`;$('boss-timer').classList.toggle('urgent',game.bossTime<=10);$('boss-hp').style.width=`${game.boss.hp/game.boss.maxHp*100}%`;$('boss-health').textContent=`${Math.ceil(game.boss.hp)} / ${game.boss.maxHp}`;}
  scene.updateMatrixWorld(true);const w=view.clientWidth,h=view.clientHeight;
  for(const e of game.events){const v=eventViews.get(e.id);if(!v)continue;if(v.flash!==undefined){if(running)v.flash=Math.max(0,v.flash-dt);v.obj.traverse(n=>{if(n.isMesh&&n.material.emissive)n.material.emissive.setHex(v.flash>0?0x663311:0);});}if(v.damageEl){if(running)v.damageTime=Math.max(0,v.damageTime-dt);v.damageEl.hidden=v.damageTime<=0;const p=new THREE.Vector3(e.x,ENEMIES[e.level]?.size||2,e.worldZ).project(camera);v.damageEl.style.left=`${(p.x*.5+.5)*w}px`;v.damageEl.style.top=`${(-p.y*.5+.5)*h-(.65-v.damageTime)*30}px`;v.damageEl.style.opacity=String(Math.min(1,v.damageTime*3));}}
  for(const l of labels){
    if(!l.parent.visible||!l.parent.parent?.visible){l.el.style.display='none';continue;}
    const p=l.parent.getWorldPosition(new THREE.Vector3()),depth=p.z;p.y+=l.y;p.project(camera);
    const visible=depth>-38&&depth<7&&p.z<1&&p.x>-1.2&&p.x<1.2&&p.y>-1.1&&p.y<.48;
    l.el.style.display=visible?'block':'none';if(visible){l.el.style.left=`${(p.x*.5+.5)*w}px`;l.el.style.top=`${(-p.y*.5+.5)*h}px`;}
  }
  renderer.render(scene,camera);
}
new ResizeObserver(()=>{const w=view.clientWidth,h=view.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;
  // Keep both edges of the road visible on narrow screens; do not crop the playable lanes.
  camera.fov=w/h<.7?55:43;camera.updateProjectionMatrix();
}).observe(view);
const loader=new GLTFLoader();
async function boot(){
  try{
    const assetNames=['apple','monkey','banana','tree','fence','crown','candy','coconut','rabbit','icecream','carrot','gingerbread','seaweed','starfish','seahorse'];
    let loaded=0;await Promise.all(assetNames.map(async name=>{const file=['candy','gingerbread'].includes(name)?`holiday/${name}`:name;models[name]=await loader.loadAsync(`${import.meta.env.BASE_URL}assets/${file}.glb`);$('load-status').textContent=`에셋 준비 ${++loaded} / ${assetNames.length}`;}));
    models.starfish.scene.rotation.x=Math.PI/2;models.seahorse.scene.rotation.y=Math.PI/2;
    prepareMaterials();$('victory-image').src=makeVictoryPortrait(renderer,models.monkey,normalize);$('victory-image').alt='게임 속 3D 원숭이가 손을 들고 축하하는 모습';
    for(const item of CATALOG)previews[item.id]=makeVictoryPortrait(renderer,models[item.model],normalize,false);
    shopUI.refresh();
    game=new Game({leaves:savedLeaves,saveLeaves:n=>{try{if(!qaMode)localStorage.setItem('orchard-leaves',String(n));}catch{}}});
    learning=learningUI({game,shop,flush:handleSignals,markLearned:()=>{tutorialDone=true;try{if(!qaMode)localStorage.setItem('orchard-v2-learned','1');}catch{}}});
    ready=true;handleSignals();$('start').disabled=false;$('start').textContent='원정 시작하기 →';$('load-status').textContent='나뭇잎과 충전된 스킬은 다음 스테이지에도 유지됩니다';
    if(import.meta.env.DEV&&qaMode){const {installQA}=await import('./qa.js');installQA(game,handleSignals);}
  }catch(e){console.error(e);$('load-status').textContent='에셋 로딩 실패 · 새로고침해서 다시 시도해주세요.';$('overlay-title').textContent='과수원을 불러오지 못했어요';}
}
let prev=performance.now();renderer.setAnimationLoop(now=>{const dt=Math.min((now-prev)/1000,.05);prev=now;update(dt);});boot();
