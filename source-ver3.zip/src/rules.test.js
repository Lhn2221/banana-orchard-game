import {test} from 'node:test';
import assert from 'node:assert/strict';
import {applyGate,makeStage,seededRandom,MAX_TROOPS,EVOLUTIONS,evolutionFor,formation,troopPower,collisionSurvivors,collisionOverlaps,spendLeaves,blastHp,readLeaves,THEMES,mergeRoster,gateRoster,rosterPower} from './rules.js';
test('gates preserve whole manpower, clamp losses and cap growth',()=>{assert.equal(applyGate(8,'+',8),16);assert.equal(applyGate(7,'÷',2),3);assert.equal(applyGate(2,'−',7),0);assert.equal(applyGate(200,'×',2),MAX_TROOPS);assert.throws(()=>applyGate(1,'÷',0));});
test('three-to-one evolution conserves every soldier including remainders',()=>{
  assert.equal(evolutionFor(30),0);assert.equal(evolutionFor(31),1);assert.equal(evolutionFor(91),2);assert.equal(evolutionFor(9,2),2);
  for(let count=1;count<=MAX_TROOPS;count++){const units=formation(count,evolutionFor(count));assert.ok(units.length<=30);assert.equal(units.reduce((n,r)=>n+EVOLUTIONS[r].weight,0),count);}
  assert.equal(troopPower(3,1,0),3.9);assert.equal(troopPower(9,2,0),14.4);assert.equal(troopPower(9,2,2),100.8);
});
test('collision losses use remaining HP and actual lateral overlap',()=>{
  assert.equal(collisionSurvivors(40,50,100),20);assert.equal(collisionSurvivors(40,100,100),0);assert.equal(collisionSurvivors(40,0,100),40);assert.equal(collisionSurvivors(7,25,100),5);
  assert.equal(collisionOverlaps(-3,1.35,3,8),false);assert.equal(collisionOverlaps(1,1.35,1,8),true);
});
test('evolved monkeys never split on penalties, and gates operate on actual units',()=>{
  const gold=mergeRoster(Array(33).fill(0));assert.deepEqual(gold,Array(11).fill(1));
  assert.equal(rosterPower(gold,0),42.9);
  assert.deepEqual(gateRoster(gold,'−',1),Array(10).fill(1));
  assert.deepEqual(gateRoster(gold,'÷',2),Array(5).fill(1));
  assert.equal(gateRoster(gold,'×',2).length,22);
  assert.equal(gateRoster(gold,'+',2).filter(r=>r===0).length,2);
});
test('leaf charges cost seven, retain excess and blast uses maximum HP',()=>{
  assert.deepEqual(spendLeaves(6),{used:false,leaves:6});assert.deepEqual(spendLeaves(9),{used:true,leaves:2});assert.deepEqual(spendLeaves(14),{used:true,leaves:7});
  assert.equal(blastHp(100,100),40);assert.equal(blastHp(20,100),0);assert.equal(readLeaves('14'),14);assert.equal(readLeaves('NaN'),0);assert.equal(readLeaves('-1'),0);
});
test('three 45-second stages randomize lanes, enemy levels and pairs; only stage three boss is crowned',()=>{
  for(let stage=1;stage<=3;stage++)for(let seed=1;seed<=30;seed++){
    const events=makeStage(stage,seededRandom(seed)),apples=events.filter(e=>e.type==='enemy');
    const gates=events.filter(e=>e.type==='gate');assert.ok(gates.every(g=>g.width>=2.2&&g.width<=2.8&&!g.options&&Math.abs(g.x)+g.width/2<=5));
    assert.ok(new Set(gates.map(g=>g.z)).size===gates.length);assert.ok(new Set(gates.map(g=>g.x)).size>2);
    assert.equal(-events.at(-1).z,223);assert.ok(apples.length>=9);assert.equal(apples.filter(e=>e.level===2).length,1);assert.equal(apples.at(-1).crowned,stage===3);
    assert.ok(apples.some(e=>e.x<0));assert.ok(apples.some(e=>e.x>0));assert.ok(apples.some((e,i)=>apples[i+1]?.z===e.z));
    assert.ok(apples.filter(e=>e.level<2).every(e=>Math.abs(e.x)<=3.3&&e.speed>0));assert.ok(events.filter(e=>e.type==='leaf').length>=8);assert.deepEqual(events.filter(e=>e.type==='item').map(e=>e.tier),[1,2]);
  }
  assert.notDeepEqual(makeStage(1,seededRandom(2)),makeStage(1,seededRandom(3)));
  for(let i=1;i<THEMES.length;i++){assert.ok(THEMES[i].trees>THEMES[i-1].trees);assert.ok(THEMES[i].fences>THEMES[i-1].fences);assert.ok(THEMES[i].ambient<THEMES[i-1].ambient);assert.ok(THEMES[i].sun<THEMES[i-1].sun);}
});
