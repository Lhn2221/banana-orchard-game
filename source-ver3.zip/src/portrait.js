import * as THREE from 'three';
import {clone} from 'three/addons/utils/SkeletonUtils.js';

// Photograph the existing CC0 game character; no replacement character is modeled.
export function makeVictoryPortrait(renderer,model,normalize,pose=true){
  const scene=new THREE.Scene(),monkey=normalize(clone(model.scene),2.2);
  scene.add(monkey);
  const wave=pose&&model.animations.find(a=>a.name.endsWith('|Wave'));
  const mixer=new THREE.AnimationMixer(monkey);
  if(wave){mixer.clipAction(wave).play();mixer.update(.65);}
  // Pose the imported fingers into a celebratory thumbs-up, keeping the thumb extended.
  if(pose)monkey.traverse(n=>{if(n.isBone&&/^(Index|Middle|Pinky)[123][._]?L$/.test(n.name))n.rotateX(1.15);});
  scene.add(new THREE.HemisphereLight(0xfff5dd,0x879a7e,3));
  const key=new THREE.DirectionalLight(0xffe9c8,3);key.position.set(3,6,5);scene.add(key);
  const fill=new THREE.DirectionalLight(0xc4e4ff,1.4);fill.position.set(-4,2,1);scene.add(fill);
  scene.updateMatrixWorld(true);
  const bounds=new THREE.Box3().setFromObject(monkey),center=bounds.getCenter(new THREE.Vector3()),size=bounds.getSize(new THREE.Vector3());
  const camera=new THREE.PerspectiveCamera(32,1,.1,30);camera.position.copy(center).add(new THREE.Vector3(.35,.2,Math.max(size.x,size.y)*2.05));camera.lookAt(center);
  const target=new THREE.WebGLRenderTarget(384,384),oldTarget=renderer.getRenderTarget(),oldColor=renderer.getClearColor(new THREE.Color()),oldAlpha=renderer.getClearAlpha(),oldShadow=renderer.shadowMap.enabled;
  const pixels=new Uint8Array(384*384*4);
  try{renderer.shadowMap.enabled=false;renderer.setRenderTarget(target);renderer.setClearColor(0x000000,0);renderer.clear();renderer.render(scene,camera);renderer.readRenderTargetPixels(target,0,0,384,384,pixels);}
  finally{renderer.setRenderTarget(oldTarget);renderer.setClearColor(oldColor,oldAlpha);renderer.shadowMap.enabled=oldShadow;target.dispose();mixer.stopAllAction();mixer.uncacheRoot(monkey);}
  const canvas=document.createElement('canvas');canvas.width=canvas.height=384;
  const ctx=canvas.getContext('2d'),data=ctx.createImageData(384,384);
  for(let row=0;row<384;row++)data.data.set(pixels.subarray((383-row)*384*4,(384-row)*384*4),row*384*4);
  ctx.putImageData(data,0,0);return canvas.toDataURL('image/png');
}
