import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Game} from './game.js';
import {seededRandom} from './rules.js';
test('same route retry restores fresh enemies and preserves leaves; new route changes layout',()=>{
  const g=new Game({random:seededRandom(12),leaves:9});g.start();const route=structuredClone(g.route);
  const e=g.events.find(e=>e.type==='enemy');g.damage(e,e.hp);g.finish(false);g.retry(true);
  assert.deepEqual(g.route,route);assert.equal(g.kills,0);assert.equal(g.leaves,9);assert.equal(g.events.some(e=>e.done),false);
  g.finish(true);const stage=g.stage;g.retry(false);assert.equal(g.stage,stage);assert.notDeepEqual(g.route,route);
});
test('lesson waits for movement and gate choice, then completes on apple destruction',()=>{
  const g=new Game();g.teaching=true;g.start();g.update(.05);assert.equal(g.distance,0);assert.equal(g.projectiles.length,0);
  g.x=g.targetX=-1;g.update(.05);assert.equal(g.lesson,'gate');
  for(let i=0;i<100;i++)g.update(.05);assert.ok(g.distance<=9);assert.equal(g.units.length,8);
  g.x=g.targetX=1.8;for(let i=0;i<4;i++)g.update(.05);assert.equal(g.lesson,'attack');assert.equal(g.units.length,20);
  const apple=g.events.find(e=>e.lesson&&e.type==='enemy');g.damage(apple,apple.hp);assert.equal(g.lesson,null);assert.ok(g.drain().some(s=>s.type==='learned'));
});
test('hit feedback reports actual HP removed, including finishing blow',()=>{const g=new Game();g.start();g.drain();const e=g.events.find(e=>e.type==='enemy');const hp=e.hp;g.damage(e,99999);assert.equal(g.drain().find(s=>s.type==='hit').amount,hp);});
