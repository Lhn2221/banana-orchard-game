// GitHub 웹 업로드용: dist의 경로를 평탄화하고 GLB의 외부 텍스처를 내장합니다.
import {readFileSync,writeFileSync,readdirSync,mkdirSync,copyFileSync} from 'node:fs';
import {join,dirname} from 'node:path';
const out='.cache/web-upload';mkdirSync(out,{recursive:true});
for(const name of readdirSync('dist/assets')){
  const path=join('dist/assets',name);if(!/\.(glb|js|css|txt)$/.test(name)||name==='candy.glb')continue;
  if(name.endsWith('.glb'))embed(path,name);
  else if(name.endsWith('.js'))writeFileSync(join(out,name),readFileSync(path,'utf8').replaceAll('assets/','').replaceAll('holiday/candy','holiday-candy').replaceAll('holiday/gingerbread','holiday-gingerbread'));
  else copyFileSync(path,join(out,name));
}
embed('dist/assets/holiday/candy.glb','holiday-candy.glb');
embed('dist/assets/holiday/gingerbread.glb','holiday-gingerbread.glb');
writeFileSync(join(out,'index.html'),readFileSync('dist/index.html','utf8').replaceAll('./assets/','./'));
copyFileSync('ASSET_CREDITS.md',join(out,'ASSET_CREDITS.md'));
writeFileSync(join(out,'README.md'),'# 바나나 원정대 ver.3\n\n학생용 정적 웹 게임입니다.\n\n- 게임: https://Lhn2221.github.io/banana-orchard-game/\n- 수정 가능한 소스: [source-ver3.zip](./source-ver3.zip)\n- 출처: [ASSET_CREDITS.md](./ASSET_CREDITS.md)\n\n소스 ZIP을 풀고 npm ci → npm run dev로 실행합니다. 수정 후 npm run build, node scripts/package-web.mjs를 실행하여 .cache/web-upload의 배포 파일을 갱신합니다. 이 저장소의 루트 파일들은 빌드 산출물입니다.\n');
function embed(path,name){
 const b=readFileSync(path),len=b.readUInt32LE(12),json=JSON.parse(b.subarray(20,20+len));
 for(const image of json.images||[])if(image.uri&&!image.uri.startsWith('data:'))image.uri='data:image/png;base64,'+readFileSync(join(dirname(path),image.uri)).toString('base64');
 const raw=Buffer.from(JSON.stringify(json)),pad=Buffer.alloc((4-raw.length%4)%4,32),body=Buffer.concat([raw,pad]),tail=b.subarray(20+len);
 const header=Buffer.from(b.subarray(0,20));header.writeUInt32LE(20+body.length+tail.length,8);header.writeUInt32LE(body.length,12);
 writeFileSync(join(out,name),Buffer.concat([header,body,tail]));
}
