// 출처 문서도 빌드 결과에 포함합니다. 서버/DB 코드는 필요하지 않습니다.
import {copyFileSync} from 'node:fs';
copyFileSync('ASSET_CREDITS.md', 'public/ASSET_CREDITS.md');
