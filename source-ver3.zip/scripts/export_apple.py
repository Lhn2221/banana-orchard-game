import bpy, os
bpy.ops.wm.open_mainfile(filepath=r'C:\Users\mihah\OneDrive\바탕 화면\Astra_Test\Apple.blend')
bpy.ops.object.select_all(action='DESELECT')
for obj in bpy.context.scene.objects:
    if obj.type in {'MESH', 'CURVE'} and any(obj.name.startswith(p) for p in ['APPLE', 'LEAF', 'STEM']):
        obj.select_set(True)
        for mat in obj.data.materials:
            if mat and mat.use_nodes:
                for node in mat.node_tree.nodes:
                    if node.type == 'TEX_IMAGE' and node.image:
                        node.image.filepath = r'C:\Users\mihah\OneDrive\바탕 화면\Astra_Test\Apple_Skin_Texture.png'
print('EXPORT_OBJECTS', [o.name for o in bpy.context.selected_objects])
bpy.context.view_layer.objects.active = bpy.context.selected_objects[0]
bpy.ops.object.convert(target='MESH')
bpy.ops.export_scene.gltf(filepath=os.path.join(os.getcwd(),'public','assets','apple.glb'), use_selection=True, export_format='GLB')
